package com.example.picupload;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity {
	Button btnSignIn, btnSignUp;
	TextView uname;
	LoginDataBaseAdapter loginDataBaseAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// create a instance of SQLite Database
		loginDataBaseAdapter = new LoginDataBaseAdapter(this);
		loginDataBaseAdapter = loginDataBaseAdapter.open();
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
	}
	public void login1(View v){
	


	// get the Refferences of views
	 final EditText editTextUserName = (EditText) findViewById(R.id.editTextUserNameToLogin);
	 final EditText editTextPassword = (EditText) findViewById(R.id.editTextPasswordToLogin);

	Button btnSignIn = (Button)findViewById(R.id.buttonSignIn);

	// Set On ClickListener

			// get The User name and Password
			String userName = editTextUserName.getText().toString();
			String password = editTextPassword.getText().toString();

			// fetch the Password form database for respective user name
			String storedPassword = loginDataBaseAdapter
					.getSinlgeEntry(userName);

			// check if the Stored password matches with Password entered by
			// user
			if (password.equals(storedPassword)) {
				Toast.makeText(Login.this,
						"Congrats: Login Successfull", Toast.LENGTH_LONG)
						.show();
				
//				setContentView(R.layout.welcome);
//				uname = (TextView)findViewById(R.id.TextView01);
//				uname.setText("welcome :" + userName);
				
				   Intent myIntent = new Intent(this,Welcome.class);
		             myIntent.putExtra("mytext",userName);
		             startActivity(myIntent);
		             finish();


			} else {
				Toast.makeText(Login.this,
						"User Name or Password does not match",
						Toast.LENGTH_LONG).show();
			  
			}
		}
	


	
}
