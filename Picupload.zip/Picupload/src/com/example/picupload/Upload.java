package com.example.picupload;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

//import com.androidexample.uploadtoserver.UploadToServer;
//import com.androidexample.uploadtoserver.UploadToServer;
import com.example.picupload.Mulpic.ImageAdapter;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
@SuppressLint("NewApi")
public class Upload extends Activity {
	ImageView imageView;
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	private ArrayList<String> imageUrls;
	private DisplayImageOptions options;
	private ImageAdapter imageAdapter;
	String user ="";
	ProgressDialog dialog = null;
	int serverResponseCode = 0;
	int PICK_IMAGES = 1;
	public static final String upLoadServerUri = "http://192.168.0.10:8080/Upload.php";
//	public static final String UPLOAD_KEY = "image";
//	public static final String TAG = "MY MESSAGE";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		user= getIntent().getStringExtra("mytext");
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.image);
		// imageAdapter = new ImageAdapter(this, imageUrls);
		//
		// GridView gridView = (GridView) findViewById(R.id.gridview);
		// gridView.setAdapter(imageAdapter);
	}

	public void ca(View v) {
		Intent intent = new Intent();
		intent.setType("image/*");
		intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		intent.setAction(Intent.ACTION_GET_CONTENT);
		startActivityForResult(Intent.createChooser(intent, "Select Picture"),
				1);

		// ArrayList<String> selectedItems = imageAdapter.getCheckedItems();
		// Toast.makeText(Upload.this,
		// "Total photos selected: "+selectedItems.size(),
		// Toast.LENGTH_SHORT).show();
		// Log.d(Mulpic.class.getSimpleName(), "Selected Items: " +
		// selectedItems.toString());

	}

	// public void onActivityResult(int requestCode, int resultCode, Intent
	// data) {
	//
	// if (resultCode == RESULT_OK) {
	//
	// Uri selectedImageUri = data.getData();
	// String s = getRealPathFromURI(selectedImageUri);
	// Toast.makeText(Upload.this, "File Upload Complete."+s,
	// Toast.LENGTH_SHORT).show();
	// }
	//
	//
	//
	//
	// }
	//
	//
	//
	public String getRealPathFromURI(Uri uri) {
		String[] projection = { MediaStore.Images.Media.DATA };
		@SuppressWarnings("deprecation")
		Cursor cursor = managedQuery(uri, projection, null, null, null);
		int column_index = cursor
				.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
		cursor.moveToNext();
		return cursor.getString(column_index);
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@SuppressLint("NewApi")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub

		if (requestCode == PICK_IMAGES) {

			if (resultCode == RESULT_OK) {
				// data.getParcelableArrayExtra(name);
				// If Single image selected then it will fetch from Gallery
				if (data.getData() != null) {

					Uri mImageUri = data.getData();
					String s = getRealPathFromURI(mImageUri);
					Toast.makeText(Upload.this, "File--->" + s,
							Toast.LENGTH_SHORT).show();
					try{
					int i=uploadFile(s);
					if(i==0){
						Toast.makeText(Upload.this, "File Not Upload Complete." + i,
								Toast.LENGTH_SHORT).show();
					}else{
						
						Toast.makeText(Upload.this, "File  Upload Complete.",
								Toast.LENGTH_SHORT).show();
					}
					}catch(Exception e){
						Toast.makeText(Upload.this, "not able to connect to server",
								Toast.LENGTH_SHORT).show();
					}
					
				
					// mArrayUri.add(uri);

					// RelativeLayout.LayoutParams lp = new
					// RelativeLayout.LayoutParams(200, 200);
					// lp.addRule(RelativeLayout.CENTER_IN_PARENT); // A
					// position in layout.
					// imageView.setLayoutParams(lp);
					// imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
					// imageView.setImageURI(mImageUri);
					// RelativeLayout layout = (RelativeLayout)
					// findViewById(R.layout.image);
					// layout.addView(imageView);

				} else {
					if (data.getClipData() != null) {
						// RelativeLayout.LayoutParams lp = new
						// RelativeLayout.LayoutParams(200, 200);
						// lp.addRule(RelativeLayout.CENTER_IN_PARENT); // A
						// position in layout.
						// imageView.setLayoutParams(lp);
						ClipData mClipData = data.getClipData();
						ArrayList<Uri> mArrayUri = new ArrayList<Uri>();
						for (int i = 0; i < mClipData.getItemCount(); i++) {

							ClipData.Item item = mClipData.getItemAt(i);
							Uri uri = item.getUri();
							String s = getRealPathFromURI(uri);
							Toast.makeText(Upload.this,
									"File----->" + s,
									Toast.LENGTH_SHORT).show();

							try{
								 i=uploadFile(s);
								if(i==0){
									Toast.makeText(Upload.this, "File Not Upload Complete." + i,
											Toast.LENGTH_SHORT).show();
								}else{
									
									Toast.makeText(Upload.this, "File  Upload Complete.",
											Toast.LENGTH_SHORT).show();
								}
								}catch(Exception e){
									Toast.makeText(Upload.this, "not able to connect to server",
											Toast.LENGTH_SHORT).show();
								}
							// List<NameValuePair> params = new
							// ArrayList<NameValuePair>(2);
							// params.add(new BasicNameValuePair("photo",s));
							//
							// HttpClient httpclient = new DefaultHttpClient();
							// HttpPost request = new HttpPost(UPLOAD_URL);
							//
							// try {
							// request.setEntity(new
							// UrlEncodedFormEntity(params));
							// } catch (UnsupportedEncodingException e1) {
							// // TODO Auto-generated catch block
							// e1.printStackTrace();
							// }
							// ResponseHandler<String> handler = new
							// BasicResponseHandler();
							// try {
							// String result = httpclient.execute(request,
							// handler);
							// } catch (ClientProtocolException e) {
							// e.printStackTrace();
							// } catch (IOException e) {
							// e.printStackTrace();
							// }

							mArrayUri.add(uri);
						}
						Log.v("LOG_TAG", "Selected Images" + mArrayUri.size());
					}

				}

			}

		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	public int uploadFile(final String sourceFileUri) {

		// upLoadServerUri = "http://192.168.1.13:80/UploadToServer.php";
		String fileName = sourceFileUri;

		HttpURLConnection conn = null;
		DataOutputStream dos = null;
		String lineEnd = "\r\n";
		String twoHyphens = "--";
		String boundary = "*****";
		int bytesRead, bytesAvailable, bufferSize;
		byte[] buffer;
		int maxBufferSize = 1 * 1024 * 1024;
		File sourceFile = new File(sourceFileUri);

		if (!sourceFile.isFile()) {

			dialog.dismiss();

			Log.e("uploadFile", "Source File not exist :" + sourceFileUri);

			runOnUiThread(new Runnable() {
				public void run() {
					Log.e("uploadFile", "Source File not exist :"
							+ sourceFileUri);
				}
			});

			return 0;

		} else {
			try {

				// open a URL connection to the Servlet
				FileInputStream fileInputStream = new FileInputStream(
						sourceFile);
				URL url = new URL(upLoadServerUri);

				// Open a HTTP connection to the URL
				conn = (HttpURLConnection) url.openConnection();
				conn.setDoInput(true); // Allow Inputs
				conn.setDoOutput(true); // Allow Outputs
				conn.setUseCaches(false); // Don't use a Cached Copy
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Connection", "Keep-Alive");
				conn.setRequestProperty("ENCTYPE", "multipart/form-data");
				conn.setRequestProperty("Content-Type",
						"multipart/form-data;boundary=" + boundary);
				conn.setRequestProperty("image", fileName);
				conn.setRequestProperty("user", user);

				dos = new DataOutputStream(conn.getOutputStream());

				dos.writeBytes(twoHyphens + boundary + lineEnd);
				dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
						+ fileName + "\"" + lineEnd);

				dos.writeBytes(lineEnd);

				// create a buffer of maximum size
				bytesAvailable = fileInputStream.available();

				bufferSize = Math.min(bytesAvailable, maxBufferSize);
				buffer = new byte[bufferSize];

				// read file and write it into form...
				bytesRead = fileInputStream.read(buffer, 0, bufferSize);

				while (bytesRead > 0) {

					dos.write(buffer, 0, bufferSize);
					bytesAvailable = fileInputStream.available();
					bufferSize = Math.min(bytesAvailable, maxBufferSize);
					bytesRead = fileInputStream.read(buffer, 0, bufferSize);

				}

				// send multipart form data necesssary after file data...
				dos.writeBytes(lineEnd);
				dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

				// Responses from the server (code and message)
				serverResponseCode = conn.getResponseCode();
				String serverResponseMessage = conn.getResponseMessage();

				Log.i("uploadFile", "HTTP Response is : "
						+ serverResponseMessage + ": " + serverResponseCode);

				if (serverResponseCode == 200) {

					runOnUiThread(new Runnable() {
						public void run() {

							String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
									
									+ upLoadServerUri;

							// messageText.setText(msg);
							Toast.makeText(Upload.this,
									"File Upload Complete.", Toast.LENGTH_SHORT)
									.show();
						}
					});
				}

				// close the streams //
				fileInputStream.close();
				dos.flush();
				dos.close();

			} catch (MalformedURLException ex) {

				Toast.makeText(Upload.this, "MalformedURLException",
						Toast.LENGTH_SHORT).show();
			} catch (Exception e) {
				Toast.makeText(Upload.this,
						"Got Exception : see logcat ",
						Toast.LENGTH_SHORT).show();
			}
			dialog.dismiss();
			return serverResponseCode;

		} // End else block
	}
}
