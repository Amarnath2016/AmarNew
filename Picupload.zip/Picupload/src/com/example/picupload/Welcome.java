package com.example.picupload;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Welcome extends Activity {
	TextView mTextview;
	String user = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		user= getIntent().getStringExtra("mytext");
		mTextview = (TextView) findViewById(R.id.TextView01);

		mTextview.setText("welcome...!"+getIntent().getStringExtra("mytext"));
	}

	public void log(View v){
		Intent intent =new Intent(this,HomeActivity.class);
		startActivity(intent);
		finish();
	}
	
	public void al(View v){

		   Intent myIntent = new Intent(this,Upload.class);
          myIntent.putExtra("mytext",user);
          startActivity(myIntent);
          finish();
	
	}
	
}
