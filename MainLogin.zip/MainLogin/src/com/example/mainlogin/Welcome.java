package com.example.mainlogin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Welcome extends Activity {
	TextView mTextview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		mTextview = (TextView) findViewById(R.id.TextView01);

		mTextview.setText("welcome...!"+getIntent().getStringExtra("mytext"));
	}

	public void log(View v){
		Intent intent =new Intent(this,HomeActivity.class);
		startActivity(intent);
		finish();
	}
	
}
